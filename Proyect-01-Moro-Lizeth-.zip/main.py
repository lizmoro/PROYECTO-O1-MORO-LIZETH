from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches


usuario_admin= "admin"
contraseña = "data3456"

usuario_entrada = input('Ingresa tu nombre de usuario: ')
usuario_contrasena = input ('Ingresa tu contraseña: ')

while usuario_contrasena != contraseña or usuario_entrada != usuario_admin:
 print('Usuario o contraseña inválidos') 
 usuario_entrada = input('Ingresa tu nombre de usuario: ')
 usuario_contrasena = input ('Ingresa tu contraseña: ')
else: 
  print ('''Bienvenido a lifestore
Elige una opción:
a. 10 Productos más vendidos
b. 20 Productos más buscados  
c. 54 Productos sin ventas/rezagados
d. 40 Productos sin búsquedas
e. 20 Productos mejor calificados
f. 20 Productos con mayor devolución
g. Ingresos por producto 
h. Ingresos totales anuales
i. Ventas promedio mensuales''')

opcion_elegida = input ('Ingresa la letra de la opción elegida: ''\n' )

if opcion_elegida == "a":
  print ("Seleccionaste: lista de los 10 productos más vendidos")
elif opcion_elegida == "b":
  print ("Seleccionaste: lista de los 20 productos más buscados")
elif opcion_elegida == "c":
  print ('Seleccionaste: lista de los 54 productos rezagados')
elif opcion_elegida =="d":
  print ('Seleccionaste: lista de los 40 productos sin búsquedas')
elif opcion_elegida == "e":
  print ('Seleccionaste: lista de los 20 productos mejor calificados')
elif opcion_elegida =="f":
 print ('Seleccionaste: lista de los 20 productos con mayor devolución')
elif opcion_elegida =="g":
 print ('Seleccionaste: Ingresos por producto')
elif opcion_elegida =="h":
 print ('Seleccionaste: Ingresos totales anuales')
elif opcion_elegida =="i":
 print ('Seleccionaste: Ventas promedio mensuales')

else:
  print ("Opción incorrecta. Intente de nuevo")
  opcion_elegida = input ('Ingresa el numero de la opcion elegida: ' )


contador = 0
ventasxproducto = []
for producto in lifestore_products:
 for venta in lifestore_sales:
   if producto[0]==venta [1]:
    contador += 1

 formato = [producto[1],contador]
 ventasxproducto.append(formato)
 contador =0

# ventasxproducto = [[producto, ventas]]
ventas_ordenadas = []
while ventasxproducto:
  minimo = ventasxproducto [0][1]
  lista_actual = ventasxproducto [0]
  for venta in ventasxproducto:
    if venta [1]> minimo:
      minimo = venta [1]
      #lista_actual = ventasxproducto
      lista_actual = venta #Asignamos lista actual
  ventas_ordenadas.append(lista_actual)
  ventasxproducto.remove (lista_actual)

if opcion_elegida == "a":
 for indice in range(0,10):
  print("Nombre del producto:","\n",ventas_ordenadas[indice][0],"\n","unidades vendidas:",ventas_ordenadas[indice][1], "\n")

if opcion_elegida == "c":
 for indice in range(42,96):
  print("Nombre del producto:","\n",ventas_ordenadas[indice][0],"\n","unidades vendidas:",ventas_ordenadas[indice][1], "\n")



contador = 0
busqueda_productos = []
for producto in lifestore_products:
 for busqueda in lifestore_searches:
   if producto[0]==busqueda [1]:
    contador += 1

 formato = [producto[1],contador]
 busqueda_productos.append(formato)
 contador =0


busquedas_ordenadas = []
while busqueda_productos:
  minimo = busqueda_productos [0][1]
  lista_actual = busqueda_productos [0]
  for busqueda in busqueda_productos:
    if busqueda [1]> minimo:
      minimo = busqueda [1]
      lista_actual = busqueda #Asignamos lista actual
  busquedas_ordenadas.append(lista_actual)
  busqueda_productos.remove(lista_actual)

#print (busquedas_ordenadas)

if opcion_elegida == "b":
 for indice in range(0,20):
  print("Nombre del producto:","\n",busquedas_ordenadas [indice][0],"\n","búsquedas:",busquedas_ordenadas[indice][1], "\n")
   
if opcion_elegida == "d":
 for indice in range(56,96):
  print("Nombre del producto:","\n",busquedas_ordenadas[indice][0],"\n"," búsquedas:",busquedas_ordenadas[indice][1], "\n")


contador = 0
suma_score = 0
productos_promedio = [] 
for producto in lifestore_products:
  for venta in lifestore_sales:
    if producto[0] == venta[1]:
      contador += 1
      suma_score += venta[2]
  promedio = suma_score // contador
  final = [producto[1], promedio]
  productos_promedio.append(final)

promedios_ordenados = []
while productos_promedio:
  minimo = productos_promedio [0][1]
  lista_actual = productos_promedio [0]
  for promedi in productos_promedio:
    if promedi [1]> minimo:
      minimo = promedi [1]
      lista_actual = promedi #Asignamos lista actual
  promedios_ordenados.append(lista_actual)
  productos_promedio.remove(lista_actual)


if opcion_elegida == "e":
 for indice in range(0,20):
  print("Nombre del producto:","\n", promedios_ordenados [indice][0],"\n","score:",promedios_ordenados [indice][1], "\n")


contador = 0
devoluciones_producto = []
for producto in lifestore_products:
  for venta in lifestore_sales:
    if producto[0] == venta[1]:
      if venta[4] == 0:
        contador += 1
  formato = [producto[1], contador]
  devoluciones_producto.append(formato)
  contador = 0
#print(devoluciones_producto)

devoluciones= []
while devoluciones_producto:
  minimo = devoluciones_producto [0][1]
  lista_actual = devoluciones_producto [0]
  for devolucion in devoluciones_producto:
    if devolucion [1]> minimo:
      minimo = devolucion [1]
      lista_actual = devolucion #Asignamos lista actual
  devoluciones.append(lista_actual)
  devoluciones_producto.remove(lista_actual)


if opcion_elegida == "f":
 for indice in range(0,20):
  print("Nombre del producto:","\n",devoluciones[indice][0],"\n","devoluciones:",devoluciones[indice][1], "\n")


contador = 0
ventas_totales = [] 
for producto in lifestore_products:
  for venta in lifestore_sales:
    if producto[0] == venta[1]:
      contador += 1
  total = producto [2] * contador
  final = [producto[0], producto[1],contador, total]
  ventas_totales.append(final)

sumo = 0
total =[]
for ven in ventas_totales:
  sumo+=ven[3]

  total.append(sumo)

suma= 0
for elemento in total:
  suma= suma + elemento
#print (suma)
if opcion_elegida == "g":
 for indice in range(0,96):
  print("Nombre del producto:","\n",ventas_totales[indice][1],"\n","ingresos:",ventas_totales[indice][3], "\n")

if opcion_elegida == "h":
  print("Ingresos generados:")
  print (suma)

if opcion_elegida == "i":
 print ("Ventas promedio mensuales:")
 print (suma//8)  